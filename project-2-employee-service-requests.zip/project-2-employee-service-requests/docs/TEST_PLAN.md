# Test plan — Employee Service Request System

Record your real results in the table below after running each case. Do not leave a test marked PASS unless you observed it.

| ID | Test | Expected result | Actual result |
|---|---|---|---|
| T1 | Open the home page | Seeded tickets and dashboard render | Not run |
| T2 | Submit a complete request | Ticket is created with an SLA due time | Not run |
| T3 | Submit an incomplete request via UI/API | Validation error is shown | Not run |
| T4 | Update ticket as Employee / Viewer | 403 authorization error | Not run |
| T5 | Update ticket as Agent | Ticket status is updated | Not run |
| T6 | Filter by status | Only matching tickets are shown | Not run |
| T7 | Check dashboard | Totals reflect stored tickets | Not run |
## How to run

1. Start the app with `npm start`.
2. Use the UI for normal cases.
3. For authorization/error cases, use the role picker and forms.
4. If using a direct API client, include `Content-Type: application/json` and `x-role: admin` / `x-role: agent` as applicable.
5. Record date, result, and any defect in `WORK_LOG.md`.

## Evidence to capture
- Main dashboard with sample records.
- One successful create/update flow.
- One rejected invalid-input case.
- One rejected unauthorized action.
- Browser console/server terminal if errors occur.
