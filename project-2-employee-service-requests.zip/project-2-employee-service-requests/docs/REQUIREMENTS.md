# Requirements — Employee Service Request System

## Problem and stakeholder
An internal employee portal to create IT/HR/facility tickets, track statuses and SLA targets, and review operational metrics. Primary stakeholders are the simulated operations/admin team and the end users who create or review records.

## Scope
- Create IT, HR, and facilities requests
- Ticket filtering by status or department
- SLA due time based on priority
- Agent role can update ticket status and priority
- Dashboard totals and overdue count
- Audit-friendly activity log

## Out of scope
- Real customer or employee data
- Production identity provider and enterprise SSO
- External payment processing, where applicable
- Production hosting, alerting, and high-availability setup

## Assumptions
- This is a local, portfolio-oriented demonstration.
- All seeded records are fictional.
- The role picker is for demonstrating authorization paths only.
- Success means core flows work locally, invalid input is rejected, data persists in SQLite, and the reviewer can reproduce the setup from the README.

## Acceptance criteria
1. Ticket form rejects missing fields
1. Priority sets a due time
1. Only agent demo role can update tickets
1. Dashboard counts match stored tickets
1. Status filters work

## Architecture
- Browser: semantic HTML, CSS, vanilla JavaScript.
- Server: Node.js + Express REST endpoints.
- Database: SQLite relational tables with startup schema creation.
- Validation: server-side checks for required fields, numeric bounds, enums, and uniqueness constraints.
- Audit: records selected create/update actions.

## Quality measures
- Functional: run the checklist in `TEST_PLAN.md`.
- Data integrity: check constraints, uniqueness, transactions where multiple records must change together.
- Reproducibility: fresh install and launch using README steps.
- Security limitations: demo roles are not real authentication; disclose this in demos.
