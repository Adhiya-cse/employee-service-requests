const express = require('express');
const path = require('path');
const Database = require('better-sqlite3');

const app = express();
const PORT = process.env.PORT || 3000;
const db = new Database(path.join(__dirname, 'data.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Database migration: create tables if they do not exist.
db.exec(`
CREATE TABLE IF NOT EXISTS tickets (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 requester TEXT NOT NULL,
 department TEXT NOT NULL,
 category TEXT NOT NULL,
 title TEXT NOT NULL,
 description TEXT NOT NULL,
 priority TEXT NOT NULL DEFAULT 'Medium',
 status TEXT NOT NULL DEFAULT 'Open',
 due_at TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS audit_log (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 actor TEXT NOT NULL,
 action TEXT NOT NULL,
 details TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const count = db.prepare('SELECT COUNT(*) AS n FROM tickets').get().n;
if (!count) {
 const add=db.prepare('INSERT INTO tickets(requester,department,category,title,description,priority,status,due_at) VALUES(?,?,?,?,?,?,?,?)');
 const now=Date.now();
 [
  ['Asha','Engineering','IT','VPN access','Cannot connect to company VPN.','High','Open',new Date(now+8*3600000).toISOString()],
  ['Rahul','People Ops','HR','Update bank details','Need to update payroll bank details.','Medium','In Progress',new Date(now+24*3600000).toISOString()],
  ['Meena','Operations','Facilities','Desk lamp broken','Desk lamp at workstation does not work.','Low','Resolved',new Date(now-3600000).toISOString()]
 ].forEach(t=>add.run(...t));
}


app.use(express.json({limit:'100kb'}));
app.use(express.static(path.join(__dirname,'public')));

// Demo identity only: select a role in the UI. Replace with real authentication before production.
app.use((req,res,next) => { req.role = String(req.header('x-role') || 'employee').toLowerCase(); next(); });
function requireRole(role) {
 return (req,res,next) => req.role === role ? next() : res.status(403).json({error:`This action requires the ${role} demo role.`});
}
function audit(actor,action,details) {
 db.prepare('INSERT INTO audit_log(actor,action,details) VALUES(?,?,?)').run(actor,action,details);
}

const categories=['IT','HR','Facilities'];
const priorities=['Low','Medium','High','Urgent'];
const statuses=['Open','In Progress','Waiting','Resolved','Closed'];
app.get('/api/tickets', (req,res) => {
 const {status,department} = req.query;
 let sql='SELECT * FROM tickets WHERE 1=1', args=[];
 if (status) {sql+=' AND status=?';args.push(status);}
 if (department) {sql+=' AND department=?';args.push(department);}
 res.json(db.prepare(sql+' ORDER BY id DESC').all(...args));
});
app.post('/api/tickets', (req,res) => {
 const {requester,department,category,title,description,priority='Medium'}=req.body;
 if (![requester,department,category,title,description].every(v=>typeof v==='string'&&v.trim())) return res.status(400).json({error:'All fields are required.'});
 if (!categories.includes(category) || !priorities.includes(priority)) return res.status(400).json({error:'Choose a valid category and priority.'});
 const hours={Low:72,Medium:24,High:8,Urgent:2}[priority];
 const due=new Date(Date.now()+hours*3600000).toISOString();
 const r=db.prepare('INSERT INTO tickets(requester,department,category,title,description,priority,status,due_at) VALUES(?,?,?,?,?,?,?,?)').run(requester.trim(),department.trim(),category,title.trim(),description.trim(),priority,'Open',due);
 audit(req.role,'TICKET_CREATED',`Ticket ${r.lastInsertRowid} created`);
 res.status(201).json(db.prepare('SELECT * FROM tickets WHERE id=?').get(r.lastInsertRowid));
});
app.patch('/api/tickets/:id', requireRole('agent'), (req,res) => {
 const {status,priority}=req.body;
 if (status && !statuses.includes(status)) return res.status(400).json({error:'Invalid status.'});
 if (priority && !priorities.includes(priority)) return res.status(400).json({error:'Invalid priority.'});
 const current=db.prepare('SELECT * FROM tickets WHERE id=?').get(Number(req.params.id));
 if (!current) return res.status(404).json({error:'Ticket not found.'});
 db.prepare('UPDATE tickets SET status=?, priority=?, updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status||current.status,priority||current.priority,current.id);
 audit(req.role,'TICKET_UPDATED',`Ticket ${current.id} updated`);
 res.json(db.prepare('SELECT * FROM tickets WHERE id=?').get(current.id));
});
app.get('/api/dashboard', (req,res) => {
 const total=db.prepare('SELECT COUNT(*) n FROM tickets').get().n;
 const open=db.prepare("SELECT COUNT(*) n FROM tickets WHERE status NOT IN ('Resolved','Closed')").get().n;
 const overdue=db.prepare("SELECT COUNT(*) n FROM tickets WHERE status NOT IN ('Resolved','Closed') AND due_at < ?").get(new Date().toISOString()).n;
 const byStatus=db.prepare('SELECT status, COUNT(*) count FROM tickets GROUP BY status').all();
 res.json({total,open,overdue,byStatus});
});
app.get('/api/audit', requireRole('agent'), (req,res) => res.json(db.prepare('SELECT * FROM audit_log ORDER BY id DESC LIMIT 100').all()));


app.get('/api/health', (req,res) => res.json({status:'ok',project:'Employee Service Request System'}));
app.use((err,req,res,next) => {
 console.error(err);
 res.status(500).json({error:'Unexpected server error.'});
});
app.listen(PORT, () => console.log(`Employee Service Request System running at http://localhost:${PORT}`));
